---
title: 'Clothes Dryer'
permalink: /browse-all-equipment-Food-Services/Clothes-Dryer
---

## Clothes Dryer

### Technical Requirements

- Heat pump technology

### Mode and Schedule of Payment 

- Direct Purchase
- Hire Purchase
- Lease

### Support Level and Conditions

Up to 70% for SMEs, 30% for non-SMEs

Applicants can apply for the EEG (Base) through the [Business Grants Portal (BGP)](http://www.businessgrants.gov.sg/){:target="_blank"}{:rel="noopener"}

### Pre-Approved Equipment Brands and Models

- Danube  - DD11HP GOLD ET2
- Danube  - DD11HP SILVER ET2
- Danube  - DD16HP GOLD ET2
- Danube  - DD16HP SILVER ET2
- Danube  - DD23HP GOLD ET2
- Danube  - DD23HP SILVER ET2
- Electrolux  - EDH803Q7WB
- Electrolux  - EDH804H3WB
- Electrolux  - EDH804H5WB
- Electrolux  - EDH903R9WB
- Imesa  - GL ES 10 EC
- Imesa  - GL ES 14 EC
- Imesa  - GL ES 18 EC
- Midea  - MDK888HP

<script src='/jquery/resize-tables.js'></script>
